﻿namespace LV5_Flyaway.Models
{
    public class Recenzija
    {
        double Ocjena;
        string Komentar;
        int KorisnikId;
    }
}
