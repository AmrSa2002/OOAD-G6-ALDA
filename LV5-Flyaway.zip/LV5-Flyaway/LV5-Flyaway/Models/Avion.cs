﻿namespace LV5_Flyaway.Models
{
    public class Avion
    {
        int ID, kapacitet;
        string Naziv;
    }
}
