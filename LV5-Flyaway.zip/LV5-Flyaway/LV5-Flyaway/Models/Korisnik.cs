﻿namespace LV5_Flyaway.Models
{
    public class Korisnik
    {
        int Id;
        string Ime, Prezime, username, e_mail, slika;
        
    }
}
