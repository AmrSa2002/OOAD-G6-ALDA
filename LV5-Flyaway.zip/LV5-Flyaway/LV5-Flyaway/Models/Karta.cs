﻿namespace LV5_Flyaway.Models
{
    public class Karta
    {
        int Broj_kreditne_kartice;
        Nacin_placanja naciniplacanja;
    }
}
