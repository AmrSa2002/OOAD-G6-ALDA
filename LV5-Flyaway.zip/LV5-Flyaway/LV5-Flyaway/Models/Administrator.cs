﻿namespace LV5_Flyaway.Models
{
    public class Administrator
    {
        public Administrator instanca;
        public Administrator()
        {
            instanca = this;
        }
        public Administrator GetInstanca()
        {
            return instanca;
        }

    }
}
