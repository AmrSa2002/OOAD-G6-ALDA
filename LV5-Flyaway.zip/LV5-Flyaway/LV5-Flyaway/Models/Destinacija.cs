﻿namespace LV5_Flyaway.Models
{
    public class Destinacija
    {
        int ID;
        string Naziv;
    }
}
