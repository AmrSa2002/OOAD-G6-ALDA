﻿namespace LV5_Flyaway.Models
{
    public enum Nacin_placanja
    {
        Kartica
    }
}
