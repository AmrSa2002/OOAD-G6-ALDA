﻿using System;

namespace LV5_Flyaway.Models
{
    public class Putnik
    {
        Boolean KupljenaKarta;
        int IdLeta;
    }
}
